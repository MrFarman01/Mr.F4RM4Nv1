#!/data/data/com.termux/files/usr/bin/bash

# Jangan Diubah Anjieng Gua Susah Buatnya
# Jangan Jadi Hacker Pengecut
# Goblog Lo Mau Ngapain
# http://www.twohidden.zone.id 
# Version 1.0

# Bersihkan Layar
clear
cd Kepo
python2 login.py


#This colour
blue='\e[0;34'
cyan='\e[0;36m'
green='\e[0;34m'
okegreen='\033[92m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'

###################################################
# CTRL C
###################################################
trap ctrl_c INT
ctrl_c() {
clear
echo -e $red"[#]> (Ctrl + C ) Detected, Trying To Exit ... "
sleep 1
echo ""
echo -e $yellow"[#]> Thank You For Using My Tools ... "
sleep 1
echo ""
echo -e $white"[#]> Click Enter ... "
read enter
exit
}

# Isi oc  :*
figlet Mr.F4RM@N | lolcat
echo ""
echo -e $red"Tool By  Mr.F4RM@!\! "
echo -e $white"Follow Me Instagram : @mr.f4rm4n  "
echo -e $red"My Site: http://www.twohidden.zone.id   "
echo -e $white"Contact Me In WhatsApp : +6285726308671  "
echo -e $red"Version : 1.0.0  "
echo -e $white"Team:  Security Cyber Two   "
echo -e $red"Thank To All Member Two_Hidden   "
echo ""
echo -e $lightgreen" 01) Red Hawk"
echo -e $lightgreen" 02) WPScan"
echo -e $lightgreen" 03) Webdav"
echo -e $lightgreen" 04) Metasploit"
echo -e $lightgreen" 05) Youtube Dl"
echo -e $lightgreen" 06) viSQL"
echo -e $lightgreen" 07) Weeman"
echo -e $lightgreen" 08) FbBrute"
echo -e $lightgreen" 09) Ngrok"
echo -e $lightgreen" 10) Hammer "
echo -e $cayn" 00) Exit "
echo -e $white""
read -p "Pilih———> " act;

if [ $act = 1 ] || [ $act = 01 ]
then
clear
echo -e $red" Installing Red Hawk "
sleep 1
apt update && apt upgrade
apt install php
apt install git
git clone https://github.com/Tuhinshubhra/RED_HAWK
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 2 ] || [ $act = 02 ]
then
clear
echo -e $red" Installing Wpscan "
sleep 1
apt-get update && apt-get upgrade
apt install ruby
apt install curl
apt install git
git clone https://github.com/wpscanteam/wpscan
cd ~/wpscan
gem install bundle
bundle config build.nokogiri --use-system-libraries
bundle install
ruby wpscan.rb --update
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 3 ] || [ $act = 03 ]
then
clear
echo -e $red" Installing Webdav "
sleep 1
apt update && apt upgrade
apt install python2
pip2 install urllib3 chardet certifi idna requests
apt install openssl curl
pkg install libcurl
mkdir webdav
cd ~/webdav
wget https://pastebin.com/raw/HnVyQPtR -O webdav.py
chmod 777 webdav.py
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 04 ] || [ $act = 4 ]
then
clear
echo -e $red" Installing Metasploit "
sleep 1
apt update && apt upgrade
apt install git
apt install wget
wget https://raw.githubusercontent.com/verluchie/termux-metasploit/master/install.sh
chmod 777 install.sh
sh install.sh
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 05 ] || [ $act = 5 ]
then
clear
echo -e $red" Installing Youtube DL "
sleep 1
apt update && apt upgrade
apt install python
pip3 install mps_youtube
pip3 install youtube_dl
apt install mpv
echo " Untuk menjalankannya ketik "mpsyt" tanpa tanda petik "
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 06 ] || [ $act = 6 ]
then
clear
echo -e $red" Installing viSQL "
sleep 1
apt update && apt upgrade
pkg install git
pkg install python2
git clone https://github.com/blackvkng/viSQL.git
cd ~/viSQL
chmod 777 viSQL.py
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 07 ] || [ $act = 7 ]
then
clear
echo -e $red" Installing Weeman "
sleep 1
apt update && apt upgrade
pkg install git
apt install python2
git clone https://github.com/samyoyo/weeman
cd ~/weeman
pip2 install beautifulsoup
pip2 install bs4
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 08 ] || [ $act = 8 ]
then
clear
sleep 1
echo -e $red" Installing FBBrute "
apt install python2
apt install python2-dev
apt install wget
pip2 install mechanize
mkdir fbbrute
cd ~/fbbrute
wget https://pastebin.com/raw/aqMBt2xA -O fbbrute.py
chmod 777 fbbrute.py
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 09 ] || [ $act = 9 ]
then
clear
echo -e $red" Installing Ngrok "
sleep 1
apt install wget
mkdir ngrok
cd ~/ngrok
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip
unzip ngrok-stable-linux-arm.zip
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 10 ] || [ $act = 10 ]
then
clear
echo -e $red" Installing Hammer "
sleep 1
pkg update
pkg upgrade
pkg install python
pkg install git
git clone https://github.com/cyweb/hammer
cd ~/
echo -e $red" T E R I N S T A L L "
fi

if [ $act = 00 ] || [ $act = 00  ]
then
echo "Thank For Using My Tools "
sleep 1
echo "Thank To All Member Securty Cyber Two "
sleep 1
echo "We Are Anonymous "
sleep 1
echo "We Are Legion "
sleep 1
echo "We Do Not Forget "
sleep 1
echo "We Do Not Forgive "
sleep 1
echo "expect us :* "
sleep 1
exit
fi
