import os, sys

print ("\033[0;34mMasukan User&Pass Dibawah")
print ("\033[0;33mThank For Using My Tools") 
print ("\033[1;32mGak Tau WhatsApp Mr.F4RM@!\! +6285726308671")
username = 'MrF4RM4N'
password = 'taek'

def restart():
	ngulang = sys.executable
	os.execl(ngulang, ngulang, *sys.argv)

def main():
	uname = raw_input("username : ")
	if uname == username:
		pwd = raw_input("password : ")

		if pwd == password:
			print "\n\033[1;34mHello Welcome To Tools Mr.F4RM@!\! ", 
			sys.exit()

		else:
			print "\n\033[1;31mSalah Password  !!!\033[00m"
			print "Back Login\n"
			restart()

	else:
		print "\n\033[1;36mSalah Username !!!\033[00m"
		print "Back Login\n"
		restart()

try:
	main()
except KeyboardInterrupt:
	os.system('clear')
	restart()